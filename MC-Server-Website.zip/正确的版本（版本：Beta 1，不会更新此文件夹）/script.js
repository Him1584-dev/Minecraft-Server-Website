document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = themeToggle.querySelector('i');
    const themeText = themeToggle.querySelector('span');
    
    const savedTheme = localStorage.getItem('mc-server-theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        themeIcon.className = 'fas fa-sun';
        themeText.textContent = '亮色主题';
    }
    
    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        
        if (document.body.classList.contains('dark-theme')) {
            themeIcon.className = 'fas fa-sun';
            themeText.textContent = '亮色主题';
            localStorage.setItem('mc-server-theme', 'dark');
        } else {
            themeIcon.className = 'fas fa-moon';
            themeText.textContent = '暗色主题';
            localStorage.setItem('mc-server-theme', 'light');
        }
    });
    
    const copyBtn = document.getElementById('copy-ip');
    const serverIp = document.getElementById('server-ip');
    
    copyBtn.addEventListener('click', function() {
        const ipText = serverIp.textContent;
        
        navigator.clipboard.writeText(ipText).then(function() {
            const originalText = copyBtn.querySelector('span').textContent;
            const originalIcon = copyBtn.querySelector('i').className;
            
            copyBtn.classList.add('copied');
            copyBtn.querySelector('span').textContent = '已复制!';
            copyBtn.querySelector('i').className = 'fas fa-check';
            
            setTimeout(function() {
                copyBtn.classList.remove('copied');
                copyBtn.querySelector('span').textContent = originalText;
                copyBtn.querySelector('i').className = originalIcon;
            }, 2000);
        }).catch(function(err) {
            console.error('复制失败: ', err);
            
            const tempInput = document.createElement('input');
            tempInput.value = ipText;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            
            const originalText = copyBtn.querySelector('span').textContent;
            const originalIcon = copyBtn.querySelector('i').className;
            
            copyBtn.classList.add('copied');
            copyBtn.querySelector('span').textContent = '已复制!';
            copyBtn.querySelector('i').className = 'fas fa-check';
            
            setTimeout(function() {
                copyBtn.classList.remove('copied');
                copyBtn.querySelector('span').textContent = originalText;
                copyBtn.querySelector('i').className = originalIcon;
            }, 2000);
        });
    });
    
    const ipDisplay = document.querySelector('.ip-display');
    ipDisplay.addEventListener('mouseenter', function() {
        this.style.boxShadow = '0 0 0 2px var(--primary-color)';
    });
    
    ipDisplay.addEventListener('mouseleave', function() {
        this.style.boxShadow = 'none';
    });
    
    document.addEventListener('keydown', function(event) {
        if ((event.ctrlKey || event.metaKey) && event.key === 'c') {
            const activeElement = document.activeElement;
            if (!activeElement || activeElement.tagName === 'BODY') {
                event.preventDefault();
                copyBtn.click();
            }
        }
        
        if (event.altKey && event.key === 't') {
            event.preventDefault();
            themeToggle.click();
        }
    });
    
    function showToast(message, type) {
        const existingToast = document.querySelector('.toast-message');
        if (existingToast) {
            existingToast.remove();
        }
        
        const toast = document.createElement('div');
        toast.className = `toast-message toast-${type}`;
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: var(--card-color);
            color: var(--text-color);
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            z-index: 1000;
            opacity: 0;
            transform: translateY(-20px);
            transition: opacity 0.3s, transform 0.3s;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateY(0)';
        }, 10);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-20px)';
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }
    
    const originalCopyHandler = copyBtn.onclick;
    copyBtn.onclick = null;
    copyBtn.addEventListener('click', function(event) {
        const ipText = serverIp.textContent;
        
        navigator.clipboard.writeText(ipText).then(function() {
            showToast('服务器IP地址已复制到剪贴板', 'success');
            
            const originalText = copyBtn.querySelector('span').textContent;
            const originalIcon = copyBtn.querySelector('i').className;
            
            copyBtn.classList.add('copied');
            copyBtn.querySelector('span').textContent = '已复制!';
            copyBtn.querySelector('i').className = 'fas fa-check';
            
            setTimeout(function() {
                copyBtn.classList.remove('copied');
                copyBtn.querySelector('span').textContent = originalText;
                copyBtn.querySelector('i').className = originalIcon;
            }, 2000);
        }).catch(function(err) {
            console.error('复制失败: ', err);
            
            const tempInput = document.createElement('input');
            tempInput.value = ipText;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            
            showToast('服务器IP地址已复制到剪贴板', 'success');
            
            const originalText = copyBtn.querySelector('span').textContent;
            const originalIcon = copyBtn.querySelector('i').className;
            
            copyBtn.classList.add('copied');
            copyBtn.querySelector('span').textContent = '已复制!';
            copyBtn.querySelector('i').className = 'fas fa-check';
            
            setTimeout(function() {
                copyBtn.classList.remove('copied');
                copyBtn.querySelector('span').textContent = originalText;
                copyBtn.querySelector('i').className = originalIcon;
            }, 2000);
        });
    });
});